/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ColoredCircles;

import java.awt.Color;
import javafx.scene.layout.Pane;

/**
 *
 * @author rahon
 */
public class CircleDrawPane extends Pane{
    int clindex = 0;
    private Color[] colorList = {Color.BLACK, Color.GRAY, Color.GREEN,
        Color.ORANGE, Color.RED, Color.WHITE, Color.YELLOW};
    }
}
